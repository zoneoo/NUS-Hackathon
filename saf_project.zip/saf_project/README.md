# Kalimantan SAF supply chain — Airbus Challenge 3

Minimum-cost network that turns Kalimantan biomass into SAF for PNK, PKN, BPN and TRK
(300 kt SAF/yr each), under the official update (challenge3_parameters.xlsx).

## Result (official parameters)

| | USD million / yr |
|---|---|
| Nearest-greedy baseline | 981.7 |
| MILP optimum (final, MIP gap 0.01%) | **890.1** |
| Saving | 91.6 (9.3%), almost all from transport |

* 6 Large refineries at Weiszfeld-refined sites in Ketapang, Kotawaringin Barat, Kotawaringin Timur,
  Kutai Kartanegara, Paser and Sanggau; 23 depots (21 Large, 2 Small), all on the refinery sites.
* 6,000 of 6,800 kt biomass used. Not used: Ketapang 531 kt (mostly the offshore-coded sites),
  Bulungan 189, Sanggau 56, Tanah Laut 24.
* About 242 kt SAF crosses west → east (Kotawaringin Timur → BPN, Sanggau → TRK). TRK's last leg is by barge.
* All 8 validation checks pass (mass balance, capacity, demand, biomass, on land, cost recompute, gap, report fields).

Facility coordinates: `outputs/facilities_v2.csv`. Flows with trips for both truck sizes: `outputs/flows_v2.csv`.
Biomass used per site: `outputs/biomass_use_v2.csv`. Everything else: `outputs/results.json`.

## Run it

```bash
pip install pandas numpy scipy scikit-learn highspy shapely pyyaml openpyxl
cd src
python s00_fetch_boundary.py   # Natural Earth Kalimantan provinces (external data, fetched by script)
python s01_load.py             # validate official files, write config/params.yaml
python s03_candidates.py       # candidate sites (k-means, Weber points, airports) + land check
python s05_solve.py            # baseline, MILP v1, Weiszfeld refinement, scenarios, final polish (~15 min)
python s06_sensitivity.py hub      # sensitivity plan library, hub model
python s06_sensitivity.py general  # c2 = 0.08 plans (run in parallel with the line above)
python s06_sensitivity.py validate # optional: library vs fresh MILP solves (not run for this submission)
python s07_build_slides.py     # outputs/SAF_Kalimantan_slides.html
```

## Stages

| Stage | Script | What it does |
|---|---|---|
| 1 Data and parameters | `s01_load.py` | Reads the official files, asserts totals (6,800 kt, 1,200 kt SAF, CapEx/20, 5% OpEx), writes `params.yaml` with official values and our own assumptions listed separately |
| 2 Distances | `common.py` | Great-circle (Haversine) × 1.3, as the update prescribes |
| 3 Candidates | `s03_candidates.py` | Refinery: district Weber points, west/east macro Weber points, airports, 15 km de-duplication. Depot: farm sites, weighted k-means centroids (K = ⌈kt/300⌉, ⌈kt/150⌉), co-located copies. Every site moved 2 km onto land if outside the Natural Earth polygon |
| 4 Model | `s04_model.py` | MILP with integer facility counts by size, flows, size-split throughput for variable OpEx, aggregate capacity cuts and strong links; HiGHS |
| 5 Solve and validate | `s05_solve.py` | Greedy baseline, MILP v1, alternating location-allocation with Weiszfeld + land projection, distributed-depot and refinery-count scenarios, 0.01% polish, 8 checks |
| 6 Sensitivity | `s06_sensitivity.py` | Plan library over demand 300–330 × yield 0.18–0.25 (all 29 feasible points; 340 kt only at yield 0.20 in this run); per point the hub MILP and the general MILP at c2 = 0.08, plus a road 1.5 / CapEx ×0.8 spot check at yield 0.20. 64 plans, largest MIP gap 0.71% |
| 7 Slides | `s07_build_slides.py`, `slides/template.html` | 6 HTML slides; every number is read from the outputs |

## Slides

`outputs/SAF_Kalimantan_slides.html` — 6 slides, open in any browser (← → to move).
Slide 6 is the interactive sensitivity explorer: five sliders (SAF yield, demand per airport, refinery CapEx,
road factor, depot → refinery rate). For the chosen demand and yield the page takes every stored
re-optimised plan, costs it exactly at the slider values (cost is linear in CapEx, road factor and rates
once a plan is fixed) and shows the cheapest one.

## Own assumptions (stated, as the brief allows)

* Barge leg to TRK uses the same great-circle × 1.3 distance as roads.
* A farm may split its biomass across depots and may be used in part.
* Depots may share a site with a refinery (the rule only asks for land in Kalimantan); a site holds several
  depots only if a refinery is open there; at most 3 refineries per site.
* Land check uses Natural Earth 1:10m Admin-1 (public domain), which predates the 2012 split of
  Kalimantan Utara, so 4 provinces cover all of Indonesian Borneo.

## Why the main model co-locates depots

For any farm F, depot P and refinery R: 0.10·d(F,P) + 0.12·d(P,R) ≥ 0.10·(d(F,P) + d(P,R)) ≥ 0.10·d(F,R),
the cost with the depot at R. Under the official rates a stand-alone depot never lowers transport; it can
only save integer rounding of depot counts (≤ USD 0.45 M per site). The general model with all 126 depot
sites confirms this (890.6, bound 890.3). It is still used for the c2 < 0.10 sensitivity case.
