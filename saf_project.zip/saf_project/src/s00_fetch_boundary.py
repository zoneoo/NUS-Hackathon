"""Stage 0 (external data): download Kalimantan province boundaries by script.

Source: Natural Earth 1:10m Cultural Vectors, Admin 1 - States, Provinces (public domain),
https://www.naturalearthdata.com/ , GeoJSON mirror maintained by the Natural Earth project:
https://github.com/nvkelso/natural-earth-vector (geojson/ne_10m_admin_1_states_provinces.geojson)

Output: data/ext/kalimantan_land.geojson = union of the 5 Indonesian provinces on Borneo.
"""
import json
import urllib.request

from shapely.geometry import mapping, shape
from shapely.ops import unary_union

from common import EXT

URL = ("https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/"
       "geojson/ne_10m_admin_1_states_provinces.geojson")
PROVINCES = {"Kalimantan Barat", "Kalimantan Tengah", "Kalimantan Selatan",
             "Kalimantan Timur", "Kalimantan Utara"}


def main():
    EXT.mkdir(parents=True, exist_ok=True)
    raw_path = EXT / "ne_10m_admin_1_states_provinces.geojson"
    if not raw_path.exists():
        print("downloading", URL)
        urllib.request.urlretrieve(URL, raw_path)
    with open(raw_path, encoding="utf-8") as f:
        gj = json.load(f)
    feats = [ft for ft in gj["features"]
             if ft["properties"].get("adm0_a3") == "IDN"
             and (ft["properties"].get("name") in PROVINCES
                  or ft["properties"].get("name_alt") in PROVINCES
                  or "Kalimantan" in str(ft["properties"].get("name")))]
    names = sorted(ft["properties"]["name"] for ft in feats)
    print("provinces found:", names)
    # Natural Earth predates Kalimantan Utara (split from Kalimantan Timur in 2012),
    # so 4 polygons already cover all of Indonesian Borneo. Check coverage instead.
    assert len(feats) in (4, 5), names
    geom = unary_union([shape(ft["geometry"]) for ft in feats])
    from shapely.geometry import Point
    assert geom.contains(Point(117.24, 2.61)), "Bulungan (North Kalimantan) not covered"
    out = {"type": "FeatureCollection",
           "features": [{"type": "Feature",
                         "properties": {"name": "Kalimantan (5 provinces)",
                                        "source": "Natural Earth 1:10m Admin-1 (public domain)",
                                        "url": URL, "provinces": names},
                         "geometry": mapping(geom)}]}
    with open(EXT / "kalimantan_land.geojson", "w", encoding="utf-8") as f:
        json.dump(out, f)
    raw_path.unlink()  # keep only the 5-province extract
    print("saved", EXT / "kalimantan_land.geojson", "bounds", geom.bounds)


if __name__ == "__main__":
    main()
