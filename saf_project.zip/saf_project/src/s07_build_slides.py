"""Stage 7: assemble every number the slides show into one JSON blob and inject it into the HTML.

Nothing on the slides is typed by hand: the page reads this blob, so re-running the pipeline
re-generates the deck with consistent numbers.
"""
import json

import pandas as pd
from shapely.geometry import shape

from common import CLEAN, EXT, OUT, ROOT, haversine_km, load_airports, load_farms, load_params, on_land


def r(x, n=3):
    return round(float(x), n)


def main():
    params, farms, airports = load_params(), load_farms(), load_airports()
    res = json.load(open(OUT / "results.json", encoding="utf-8"))
    use = pd.read_csv(OUT / "biomass_use_v2.csv")
    refs_final = pd.read_csv(CLEAN / "refinery_candidates_final.csv")
    deps = pd.read_csv(CLEAN / "depot_candidates.csv")

    # Kalimantan outline, simplified for drawing
    gj = json.load(open(EXT / "kalimantan_land.geojson", encoding="utf-8"))
    geom = shape(gj["features"][0]["geometry"]).simplify(0.02, preserve_topology=True)
    polys = list(geom.geoms) if geom.geom_type == "MultiPolygon" else [geom]
    outline = [[[r(x, 3), r(y, 3)] for x, y in p.exterior.coords] for p in polys if p.area > 0.002]

    offshore = {f.location_id for f in farms.itertuples() if not on_land(f.latitude, f.longitude)}
    farm_rows = [{"id": u.location_id, "d": u.district, "lat": r(u.latitude), "lon": r(u.longitude),
                  "kt": r(u.production_kilotons, 2), "used": r(u.used_kt, 2),
                  "offshore": u.location_id in offshore} for u in use.itertuples()]

    fin = res["final"]
    plan = fin["plan"]
    dep2ref = {d["id"]: d["colocated_with"] for d in plan["depots"]}
    farm_ll = {f["id"]: (f["lat"], f["lon"]) for f in farm_rows}
    refl = {x["id"]: x for x in plan["refineries"]}
    flows_fr = {}
    for f in plan["flows_fd"]:
        key = (f["farm"], dep2ref[f["depot"]])
        flows_fr[key] = flows_fr.get(key, 0) + f["kt"]

    def short(src):
        return src.split(":")[-1]

    final = {
        "refineries": [{"id": x["id"], "name": short(x["source"]), "lat": r(x["lat"]), "lon": r(x["lon"]),
                        "nL": x["n_L"], "nS": x["n_S"], "kt": r(x["intake_kt"], 1)} for x in plan["refineries"]],
        "depots": [{"id": d["id"], "ref": d["colocated_with"], "nL": d["n_L"], "nS": d["n_S"],
                    "kt": r(d["throughput_kt"], 1)} for d in plan["depots"]],
        "farm_flows": [{"farm": k[0], "ref": k[1], "kt": r(v, 2)} for k, v in flows_fr.items()],
        "saf_flows": [{"ref": f["refinery"], "ap": f["airport"], "kt": r(f["kt"], 1),
                       "road_km": r(f["gc_km"] * 1.3, 0)} for f in plan["flows_ra"]],
        "cost": {k: r(v, 3) for k, v in fin["cost"].items() if isinstance(v, (int, float))},
        "checks": fin["checks"], "gap": fin["gap"], "bound": fin["dual_bound"],
    }
    trips = pd.read_csv(OUT / "flows_v2.csv")
    final["trips"] = {
        "farm_hub_large": int(trips[trips.leg == "Farm to depot"].trips_large.sum()),
        "farm_hub_small": int(trips[trips.leg == "Farm to depot"].trips_small.sum()),
        "saf_truck_large": int(trips[(trips.leg == "Refinery to airport") & (trips["mode"] == "truck")].trips_large.sum()),
        "saf_barge_kt": r(trips[trips["mode"].str.startswith("barge")].kt.sum(), 1),
    }
    west = farms.longitude < 113.5

    def cost_lines(c):
        return {"refinery_fixed": r(c["refinery_fixed"]), "depot_fixed": r(c["depot_fixed"]),
                "var_opex": r(c["refinery_var"] + c["depot_var"]), "refinery_var": r(c["refinery_var"]),
                "depot_var": r(c["depot_var"]), "transport": r(c["transport"]),
                "transport_fd": r(c["transport_fd"]), "transport_dr": r(c["transport_dr"]),
                "transport_ra": r(c["transport_ra"]), "total": r(c["total_musd"])}

    base_plan = res["baseline"]["plan"]
    data = {
        "params": {"yield": params["yield"], "road": params["road_factor"], "rates": params["rates"],
                   "refinery": params["refinery"], "depot": params["depot"]},
        "outline": outline,
        "farms": farm_rows,
        "airports": [{"iata": a.iata, "city": a.city if a.iata != "TRK" else "Tarakan", "lat": r(a.latitude),
                      "lon": r(a.longitude), "demand": float(a.saf_demand_kt_per_year)} for a in airports.itertuples()],
        "insights": {
            "west_kt": r(farms[west].production_kilotons.sum(), 2), "east_kt": r(farms[~west].production_kilotons.sum(), 2),
            "west_n": int(west.sum()), "east_n": int((~west).sum()),
            "offshore_n": len(offshore),
            "offshore_ketapang": sum(1 for f in farm_rows if f["offshore"] and f["d"] == "Ketapang"),
        },
        "candidates": {
            "refinery_initial": int(len(pd.read_csv(CLEAN / "refinery_candidates.csv"))),
            "refinery_raw": 2 * farms.district.nunique() + 2 + len(airports),
            "refinery_final": [{"src": x.source, "lat": r(x.lat), "lon": r(x.lon), "moved": r(x.moved_to_land_km, 1)}
                               for x in refs_final.itertuples()],
            "depot_total": int(len(deps)),
            "depot_by_type": deps.source.str.split(":").str[0].value_counts().to_dict(),
            "depot_moved": int((deps.moved_to_land_km > 0).sum()),
            "kmeans": [{"lat": r(x.lat), "lon": r(x.lon)} for x in deps.itertuples() if x.source.startswith("kmeans")],
        },
        "final": final,
        "baseline": {"cost": cost_lines(res["baseline"]["cost"]),
                     "refineries": [{"name": short(x["source"]), "lat": r(x["lat"]), "lon": r(x["lon"])} for x in base_plan["refineries"]],
                     "depots": [{"lat": r(d["lat"]), "lon": r(d["lon"])} for d in base_plan["depots"]]},
        "v1": {"cost": cost_lines(res["v1"]["cost"]), "gap": res["v1"]["gap"], "runtime": r(res["v1"]["runtime"], 1)},
        "final_lines": cost_lines(fin["cost"]),
        "general_check": res["general_check"],
        "refine_history": [{"iter": h["iter"], "total": r(h["total"]), "added": h.get("added")} for h in res["v2"]["history"]],
        "distributed": cost_lines(res["distributed_depots"]["cost"]) if "distributed_depots" in res else None,
        "distributed_detail": ({"nL": res["distributed_depots"]["cost"]["n_depot"]["Large"],
                                "nS": res["distributed_depots"]["cost"]["n_depot"]["Small"]}
                               if "distributed_depots" in res else None),
        "curve": [{"N": c["N"], "total": r(c["total"]), "transport": r(c["transport"]), "nL": c["n_ref"]["Large"],
                   "nS": c["n_ref"]["Small"]} for c in res["refinery_count_curve"]],
    }
    lib_path = OUT / "sensitivity_plans.jsonl"
    lib = [json.loads(l) for l in lib_path.read_text().splitlines()] if lib_path.exists() else []
    data["library"] = [{k: (r(v, 4) if isinstance(v, float) else v) for k, v in p.items()
                        if k in ("D", "y", "kind", "RF", "DF", "VO", "T1", "T2", "T3", "nL", "nS", "nDepot",
                                 "colocated", "biomass", "refs", "depots_far", "infeasible", "gap")}
                       for p in lib]
    fc = fin["cost"]
    data["library"].append({"D": 300, "y": 0.2, "kind": "final", "RF": r(fc["fixed_at_m1"]["refinery"], 4),
                            "DF": r(fc["depot_fixed"], 4), "VO": r(fc["var_opex"], 4),
                            "T1": r(fc["tkm_gc"]["fd"] / 1e6, 4), "T2": r(fc["tkm_gc"]["dr"] / 1e6, 4),
                            "T3": r(fc["tkm_gc"]["ra"] / 1e6, 4), "nL": fc["n_ref"]["Large"], "nS": fc["n_ref"]["Small"],
                            "nDepot": fc["n_depot"]["Large"] + fc["n_depot"]["Small"],
                            "colocated": round(fc["colocated_share"], 3), "biomass": round(fc["biomass_used_kt"], 1),
                            "refs": [{"lat": x["lat"], "lon": x["lon"], "nL": x["nL"], "nS": x["nS"], "kt": x["kt"]}
                                     for x in final["refineries"]], "depots_far": 0, "gap": fin["gap"]})
    vpath = OUT / "sensitivity_validation.json"
    data["library_validation"] = json.load(open(vpath)) if vpath.exists() else []

    tpl = (ROOT / "slides" / "template.html").read_text(encoding="utf-8")
    html = tpl.replace("/*__DATA__*/null", json.dumps(data, ensure_ascii=False, separators=(",", ":")))
    (OUT / "SAF_Kalimantan_slides.html").write_text(html, encoding="utf-8")
    with open(OUT / "slides_data.json", "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    print("library plans:", len(data["library"]), "| html bytes:", len(html))


if __name__ == "__main__":
    main()
