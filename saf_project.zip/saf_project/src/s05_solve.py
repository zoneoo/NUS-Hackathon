"""Stage 5: baseline, MILP v1 (discrete candidates), Weiszfeld refinement v2, validation.

Main model = "hub" form: depots may only sit at refinery candidate sites (co-located).
Why this is safe under the official rates (c2 = 0.12 >= c1 = 0.10): for any route
farm F -> depot P -> refinery R,  c1*d(F,P) + c2*d(P,R) >= c1*(d(F,P) + d(P,R)) >= c1*d(F,R),
which is exactly the cost of a depot placed at R (triangle inequality). The only thing a
stand-alone depot could save is integer rounding of depot counts (<= USD 0.45M per site).
The general model (stand-alone depots allowed) is solved as a check and for c2 < c1 scenarios.
"""
import json
from math import ceil

import numpy as np
import pandas as pd

from common import CLEAN, OUT, haversine_km, load_airports, load_farms, load_params, on_land, project_to_land
from s03_candidates import weber_point
from s04_model import Scenario, evaluate_plan, solve, to_plan

LOWER_BOUND_MUSD = 822.0  # 6 Large refineries + 20 Large depots fixed + variable OpEx on 6,000 kt


# ------------------------------------------------------------------ baseline (greedy, intuitive)
def greedy_baseline(farms, airports, params, sc: Scenario):
    QR = params["refinery"]["Large"]["capacity_t"] / 1000
    QD = params["depot"]["Large"]["capacity_t"] / 1000
    B = len(airports) * sc.demand_kt / sc.yield_
    # 1) one Large refinery at each big district's weighted centroid until capacity covers demand
    dist = (farms.groupby("district")
            .apply(lambda g: pd.Series({"kt": g.production_kilotons.sum(),
                                        "lat": np.average(g.latitude, weights=g.production_kilotons),
                                        "lon": np.average(g.longitude, weights=g.production_kilotons)}),
                   include_groups=False)
            .sort_values("kt", ascending=False))
    refs, cap = [], 0.0
    for d, r in dist.iterrows():
        if cap >= B:
            break
        la, lo, _ = project_to_land(r.lat, r.lon)
        refs.append({"id": f"R{len(refs) + 1}", "source": f"baseline:{d}", "lat": la, "lon": lo,
                     "n_L": 1, "n_S": 0, "intake_kt": 0.0})
        cap += QR
    # 2) farms fill their nearest refinery (closest farms first) until 6,000 kt is reached
    fr = haversine_km(farms.latitude.values[:, None], farms.longitude.values[:, None],
                      np.array([r["lat"] for r in refs])[None, :], np.array([r["lon"] for r in refs])[None, :])
    left = {r["id"]: QR for r in refs}
    alloc = []  # (farm idx, refinery idx, kt)
    need = B
    for i in np.argsort(fr.min(1)):
        supply = farms.production_kilotons[i]
        for k in np.argsort(fr[i]):
            if need <= 1e-9 or supply <= 1e-9:
                break
            take = min(supply, left[refs[k]["id"]], need)
            if take > 0:
                alloc.append((i, k, take))
                left[refs[k]["id"]] -= take
                supply -= take
                need -= take
    # 3) conventional depots near the farms: k-means per refinery catchment, Large depots
    from sklearn.cluster import KMeans
    depots, flows_fd, flows_dr = [], [], []
    for k, r in enumerate(refs):
        items = [(i, kt) for (i, kk, kt) in alloc if kk == k]
        total = sum(kt for _, kt in items)
        r["intake_kt"] = total
        nd = max(1, ceil(total / QD))
        pts = np.array([[farms.latitude[i], farms.longitude[i]] for i, _ in items])
        wts = np.array([kt for _, kt in items])
        km = KMeans(n_clusters=min(nd, len(items)), n_init=10, random_state=0).fit(pts, sample_weight=wts)
        dep_ids = []
        for c in km.cluster_centers_:
            la, lo, _ = project_to_land(c[0], c[1])
            did = f"D{len(depots) + 1}"
            depots.append({"id": did, "source": f"baseline:near-farms:{r['source']}", "lat": la, "lon": lo,
                           "n_L": 1, "n_S": 0, "throughput_kt": 0.0, "colocated_with": None})
            dep_ids.append(len(depots) - 1)
        room = {d: QD for d in dep_ids}
        for i, kt in items:
            dd = sorted(dep_ids, key=lambda d: haversine_km(farms.latitude[i], farms.longitude[i],
                                                            depots[d]["lat"], depots[d]["lon"]))
            for d in dd:
                take = min(kt, room[d])
                if take > 0:
                    gc = float(haversine_km(farms.latitude[i], farms.longitude[i], depots[d]["lat"], depots[d]["lon"]))
                    flows_fd.append({"farm": farms.location_id[i], "depot": depots[d]["id"], "kt": take, "gc_km": gc})
                    depots[d]["throughput_kt"] += take
                    room[d] -= take
                    kt -= take
                if kt <= 1e-9:
                    break
            if kt > 1e-9:  # all depots full: open one more at the farm
                la, lo, _ = project_to_land(farms.latitude[i], farms.longitude[i])
                depots.append({"id": f"D{len(depots) + 1}", "source": "baseline:extra", "lat": la, "lon": lo,
                               "n_L": 1, "n_S": 0, "throughput_kt": kt, "colocated_with": None})
                dep_ids.append(len(depots) - 1)
                flows_fd.append({"farm": farms.location_id[i], "depot": depots[-1]["id"], "kt": kt,
                                 "gc_km": float(haversine_km(farms.latitude[i], farms.longitude[i], la, lo))})
        for d in dep_ids:
            if depots[d]["throughput_kt"] > 0:
                flows_dr.append({"depot": depots[d]["id"], "refinery": r["id"], "kt": depots[d]["throughput_kt"],
                                 "gc_km": float(haversine_km(depots[d]["lat"], depots[d]["lon"], r["lat"], r["lon"]))})
    depots = [d for d in depots if d["throughput_kt"] > 0]
    # 4) SAF: nearest refinery-airport pairs first
    saf_left = {r["id"]: r["intake_kt"] * sc.yield_ for r in refs}
    dem_left = {a: sc.demand_kt for a in airports.iata}
    pairs = sorted(((float(haversine_km(r["lat"], r["lon"], a.latitude, a.longitude)), r["id"], a.iata)
                    for r in refs for a in airports.itertuples()))
    flows_ra = []
    for gc, rid, iata in pairs:
        take = min(saf_left[rid], dem_left[iata])
        if take > 1e-9:
            flows_ra.append({"refinery": rid, "airport": iata, "kt": take, "gc_km": gc})
            saf_left[rid] -= take
            dem_left[iata] -= take
    return {"refineries": refs, "depots": depots, "flows_fd": flows_fd, "flows_dr": flows_dr, "flows_ra": flows_ra}


# ------------------------------------------------------------------ validation
def validate(plan, farms, airports, params, sc, cost, solver_obj=None, gap=None):
    checks = []
    tol = 1e-4
    dep_in = {d["id"]: 0.0 for d in plan["depots"]}
    for f in plan["flows_fd"]:
        dep_in[f["depot"]] += f["kt"]
    dep_out = {d["id"]: 0.0 for d in plan["depots"]}
    for f in plan["flows_dr"]:
        dep_out[f["depot"]] += f["kt"]
    ref_in = {r["id"]: 0.0 for r in plan["refineries"]}
    for f in plan["flows_dr"]:
        ref_in[f["refinery"]] += f["kt"]
    ref_out = {r["id"]: 0.0 for r in plan["refineries"]}
    for f in plan["flows_ra"]:
        ref_out[f["refinery"]] += f["kt"]
    mb = all(abs(dep_in[d] - dep_out[d]) < tol for d in dep_in) and \
        all(abs(ref_in[r] * sc.yield_ - ref_out[r]) < tol for r in ref_in)
    checks.append(("质量守恒 Mass balance", mb, "depot in = out; refinery in x 0.20 = SAF out"))
    QD = {s: params["depot"][s]["capacity_t"] / 1000 for s in ("Small", "Large")}
    QR = {s: params["refinery"][s]["capacity_t"] / 1000 for s in ("Small", "Large")}
    util_d = [dep_in[d["id"]] / (d["n_L"] * QD["Large"] + d["n_S"] * QD["Small"]) for d in plan["depots"]]
    util_r = [ref_in[r["id"]] / (r["n_L"] * QR["Large"] + r["n_S"] * QR["Small"]) for r in plan["refineries"]]
    checks.append(("容量 Capacity", max(util_d + util_r) <= 1 + 1e-6,
                   f"max utilisation {max(util_d + util_r):.1%}; refinery min {min(util_r):.1%}"))
    got = {a: 0.0 for a in airports.iata}
    for f in plan["flows_ra"]:
        got[f["airport"]] += f["kt"]
    checks.append(("需求 Demand", all(got[a] >= sc.demand_kt - tol for a in got),
                   ", ".join(f"{a} {got[a]:.1f} kt" for a in got)))
    used = {fid: 0.0 for fid in farms.location_id}
    for f in plan["flows_fd"]:
        used[f["farm"]] += f["kt"]
    supply_ok = all(used[r.location_id] <= r.production_kilotons + tol for r in farms.itertuples())
    need = len(airports) * sc.demand_kt / sc.yield_
    checks.append(("用量 Biomass", supply_ok and abs(sum(used.values()) - need) < 1e-3,
                   f"used {sum(used.values()):.1f} kt of {farms.production_kilotons.sum():.0f}"))
    land = all(on_land(x["lat"], x["lon"]) for x in plan["refineries"] + plan["depots"])
    checks.append(("位置 On land", land, "all facility coordinates inside Kalimantan polygon"))
    if solver_obj is not None:
        ok = abs(solver_obj - cost["total_musd"]) < 1e-3 * max(1, solver_obj) and cost["total_musd"] >= LOWER_BOUND_MUSD - 1e-6
        checks.append(("成本重算 Cost recompute", ok,
                       f"solver {solver_obj:.3f} vs recomputed {cost['total_musd']:.3f} M USD (>= {LOWER_BOUND_MUSD})"))
    else:
        checks.append(("成本重算 Cost recompute", cost["total_musd"] >= LOWER_BOUND_MUSD,
                       f"recomputed {cost['total_musd']:.3f} M USD (>= {LOWER_BOUND_MUSD})"))
    if gap is not None:
        checks.append(("最优性 Optimality", gap <= 0.005 + 1e-9, f"MIP gap {gap:.3%}"))
    fields = all(k in plan for k in ("refineries", "depots", "flows_fd", "flows_dr", "flows_ra"))
    checks.append(("报告字段 Report fields", fields, "coordinates, sizes, flows, trips, barge leg"))
    return checks, {"depot_util": util_d, "refinery_util": util_r, "used": used}


# ------------------------------------------------------------------ refinement (Weiszfeld per hub)
def refine_hubs(plan, farms, airports, sc):
    """Hubs (refinery + co-located depots) have fixed neighbours only (farms, airports), so the
    joint Weber problem separates: one weighted geometric median per hub."""
    fidx = {fid: i for i, fid in enumerate(farms.location_id)}
    dep2ref = {d["id"]: d["colocated_with"] for d in plan["depots"]}
    new = []
    for r in plan["refineries"]:
        lat, lon, w = [], [], []
        for f in plan["flows_fd"]:
            if dep2ref.get(f["depot"]) == r["id"]:
                i = fidx[f["farm"]]
                lat.append(farms.latitude[i]); lon.append(farms.longitude[i]); w.append(sc.c1 * f["kt"])
        for f in plan["flows_ra"]:
            if f["refinery"] == r["id"]:
                a = airports[airports.iata == f["airport"]].iloc[0]
                lat.append(a.latitude); lon.append(a.longitude); w.append(sc.c3 * f["kt"])
        wla, wlo = weber_point(np.array(lat), np.array(lon), np.array(w))
        pla, plo, moved = project_to_land(wla, wlo)
        new.append({"from": r["source"], "weber_lat": wla, "weber_lon": wlo, "lat": pla, "lon": plo,
                    "moved_to_land_km": moved,
                    "shift_km": float(haversine_km(r["lat"], r["lon"], pla, plo))})
    return new


def add_candidates(depots, refs, new, tag):
    rows_r, rows_d = [], []
    for n in new:
        if any(haversine_km(n["lat"], n["lon"], a, b) < 0.2 for a, b in zip(refs.lat, refs.lon)):
            continue
        rows_r.append({"kind": "refinery", "source": f"refined:{tag}:{n['from'].split(':', 1)[-1]}",
                       "lat": n["lat"], "lon": n["lon"], "raw_lat": n["weber_lat"], "raw_lon": n["weber_lon"],
                       "moved_to_land_km": round(n["moved_to_land_km"], 2)})
    refs2 = pd.concat([refs, pd.DataFrame(rows_r)], ignore_index=True)
    for k in range(len(refs), len(refs2)):
        r = refs2.iloc[k]
        rows_d.append({"kind": "depot", "source": f"co-located:{r.source}", "lat": r.lat, "lon": r.lon,
                       "raw_lat": r.raw_lat, "raw_lon": r.raw_lon, "moved_to_land_km": r.moved_to_land_km,
                       "is_ref_site": True, "ref_idx": k})
    depots2 = pd.concat([depots, pd.DataFrame(rows_d)], ignore_index=True)
    return depots2, refs2, len(rows_r)


def hub_depots(depots):
    return depots[depots.is_ref_site].reset_index(drop=True)


def trips_table(plan, params):
    tk = params["trucks_t"]
    rows = []
    for leg, flows, key in (("Farm to depot", plan["flows_fd"], "depot"),
                            ("Depot to refinery", plan["flows_dr"], "refinery"),
                            ("Refinery to airport", plan["flows_ra"], "airport")):
        for f in flows:
            mode = "barge (last leg)" if leg == "Refinery to airport" and f[key] == "TRK" else "truck"
            co = leg == "Depot to refinery" and f["gc_km"] < 0.5
            t = f["kt"] * 1000
            rows.append({"leg": leg, "from": f.get("farm", f.get("depot", f.get("refinery"))), "to": f[key],
                         "kt": round(f["kt"], 3), "road_km": round(f["gc_km"] * 1.3, 1), "mode": "on-site" if co else mode,
                         "trips_large": 0 if co else ceil(t / tk[leg]["large"]),
                         "trips_small": 0 if co else ceil(t / tk[leg]["small"])})
    return pd.DataFrame(rows)


def jsonable(obj):
    if isinstance(obj, dict):
        return {k: jsonable(v) for k, v in obj.items() if not isinstance(v, np.ndarray)}
    if isinstance(obj, list):
        return [jsonable(v) for v in obj]
    if isinstance(obj, (np.floating, np.integer)):
        return obj.item()
    return obj


def finalize():
    """Polish: re-solve the final candidate set to a 0.01% gap, validate, and write all outputs."""
    params, farms, airports = load_params(), load_farms(), load_airports()
    d_cur = pd.read_csv(CLEAN / "depot_candidates_final.csv")
    r_cur = pd.read_csv(CLEAN / "refinery_candidates_final.csv")
    sc = Scenario()
    with open(OUT / "results.json", encoding="utf-8") as f:
        report = json.load(f)
    s = solve(farms, airports, hub_depots(d_cur), r_cur, params, sc, time_limit=500, gap=1e-4)
    plan = to_plan(s, farms, airports, hub_depots(d_cur), r_cur, params)
    cost = evaluate_plan(plan, params, sc)
    checks, util = validate(plan, farms, airports, params, sc, cost, s["objective_musd"], s["mip_gap"])
    moves = refine_hubs(plan, farms, airports, sc)
    report["final"] = {"cost": cost, "checks": checks, "plan": plan, "gap": s["mip_gap"],
                       "dual_bound": s["dual_bound"], "runtime": s["runtime"],
                       "weber_shift_km_after": [round(m["shift_km"], 2) for m in moves]}
    print(f"final total {cost['total_musd']:.3f} M USD/yr, gap {s['mip_gap']:.4%}")
    for name, ok, msg in checks:
        print(f"   [{'PASS' if ok else 'FAIL'}] {name}: {msg}")
    cur_plan = plan
    # ---- outputs
    fac = pd.DataFrame([{"type": "refinery", **r} for r in cur_plan["refineries"]] +
                       [{"type": "depot", **d} for d in cur_plan["depots"]])
    fac.to_csv(OUT / "facilities_v2.csv", index=False)
    trips_table(cur_plan, params).to_csv(OUT / "flows_v2.csv", index=False)
    used = util["used"]
    farms.assign(used_kt=[round(used[f], 3) for f in farms.location_id],
                 dropped_kt=[round(r.production_kilotons - used[r.location_id], 3) for r in farms.itertuples()]
                 ).to_csv(OUT / "biomass_use_v2.csv", index=False)
    with open(OUT / "results.json", "w", encoding="utf-8") as f:
        json.dump(jsonable(report), f, ensure_ascii=False, indent=1, default=str)
    print("saved outputs")


def main():
    OUT.mkdir(exist_ok=True)
    params, farms, airports = load_params(), load_farms(), load_airports()
    depots = pd.read_csv(CLEAN / "depot_candidates.csv")
    refs = pd.read_csv(CLEAN / "refinery_candidates.csv")
    sc = Scenario()
    report = {}

    # ---- baseline
    base_plan = greedy_baseline(farms, airports, params, sc)
    base_cost = evaluate_plan(base_plan, params, sc)
    base_checks, _ = validate(base_plan, farms, airports, params, sc, base_cost)
    report["baseline"] = {"cost": base_cost, "checks": base_checks, "plan": base_plan}
    print(f"baseline total {base_cost['total_musd']:.2f} M USD/yr  refineries {base_cost['n_ref']} depots {base_cost['n_depot']}")

    # ---- v1: hub MILP on discrete candidates (first valid submission)
    s1 = solve(farms, airports, hub_depots(depots), refs, params, sc, time_limit=300, gap=0.001)
    p1 = to_plan(s1, farms, airports, hub_depots(depots), refs, params)
    c1 = evaluate_plan(p1, params, sc)
    ch1, _ = validate(p1, farms, airports, params, sc, c1, s1["objective_musd"], s1["mip_gap"])
    report["v1"] = {"cost": c1, "checks": ch1, "plan": p1, "gap": s1["mip_gap"], "runtime": s1["runtime"]}
    print(f"v1 total {c1['total_musd']:.3f} (solver {s1['objective_musd']:.3f}, gap {s1['mip_gap']:.3%}, {s1['runtime']:.0f}s)")

    # ---- general model check: stand-alone depots allowed (should not beat the hub model)
    sg = solve(farms, airports, depots, refs, params, sc, time_limit=300, gap=0.001)
    report["general_check"] = {"total": sg.get("total_musd"), "gap": sg.get("mip_gap"),
                               "bound": sg.get("dual_bound"), "runtime": sg["runtime"], "status": sg["status"]}
    print(f"general model (stand-alone depots allowed): {sg.get('total_musd'):.3f}, bound {sg.get('dual_bound'):.3f}, status {sg['status']}")

    # ---- v2: alternating location-allocation with Weiszfeld + land projection
    history = [{"iter": 0, "total": c1["total_musd"], "K": len(refs)}]
    cur_plan, cur_cost, cur_sol = p1, c1, s1
    d_cur, r_cur = depots.copy(), refs.copy()
    for it in range(1, 7):
        new = refine_hubs(cur_plan, farms, airports, sc)
        d_cur, r_cur, added = add_candidates(d_cur, r_cur, new, f"it{it}")
        s2 = solve(farms, airports, hub_depots(d_cur), r_cur, params, sc, time_limit=300, gap=0.001)
        p2 = to_plan(s2, farms, airports, hub_depots(d_cur), r_cur, params)
        c2_ = evaluate_plan(p2, params, sc)
        improve = (cur_cost["total_musd"] - c2_["total_musd"]) / cur_cost["total_musd"]
        history.append({"iter": it, "total": c2_["total_musd"], "K": len(r_cur), "added": added,
                        "improvement": improve, "moves": new})
        print(f"  refine it{it}: added {added} sites, total {c2_['total_musd']:.3f}, improvement {improve:.4%}")
        if c2_["total_musd"] < cur_cost["total_musd"]:
            cur_plan, cur_cost, cur_sol = p2, c2_, s2
        if improve < 0.001 or added == 0:
            break
    ch2, util = validate(cur_plan, farms, airports, params, sc, cur_cost, cur_sol["objective_musd"], cur_sol["mip_gap"])
    report["v2"] = {"cost": cur_cost, "checks": ch2, "plan": cur_plan, "gap": cur_sol["mip_gap"],
                    "history": history}
    r_cur.to_csv(CLEAN / "refinery_candidates_final.csv", index=False)
    d_cur.to_csv(CLEAN / "depot_candidates_final.csv", index=False)
    print(f"v2 total {cur_cost['total_musd']:.3f}")
    for name, ok, msg in ch2:
        print(f"   [{'PASS' if ok else 'FAIL'}] {name}: {msg}")

    # ---- scenario: conventional distributed depots (farm -> depot <= 50 road km)
    sd = solve(farms, airports, d_cur, r_cur, params, Scenario(max_farm_depot_km=50, label="distributed"),
               time_limit=300, gap=0.002)
    if sd["feasible"]:
        pdd = to_plan(sd, farms, airports, d_cur, r_cur, params)
        cdd = evaluate_plan(pdd, params, Scenario())
        report["distributed_depots"] = {"cost": cdd, "gap": sd["mip_gap"], "plan": pdd}
        print(f"distributed depots (<=50 km): {cdd['total_musd']:.3f}  (+{cdd['total_musd'] - cur_cost['total_musd']:.2f})")

    # ---- refinery count curve
    curve = []
    for N in range(6, 10):
        sn = solve(farms, airports, hub_depots(d_cur), r_cur, params, Scenario(force_n_refineries=N),
                   time_limit=200, gap=0.002)
        if sn["feasible"]:
            pn = to_plan(sn, farms, airports, hub_depots(d_cur), r_cur, params)
            cn = evaluate_plan(pn, params, Scenario())
            curve.append({"N": N, "total": cn["total_musd"], "fixed": cn["refinery_fixed"] + cn["depot_fixed"],
                          "var": cn["var_opex"], "transport": cn["transport"], "n_ref": cn["n_ref"]})
            print(f"  N={N}: total {cn['total_musd']:.2f}  transport {cn['transport']:.2f}  {cn['n_ref']}")
    report["refinery_count_curve"] = curve

    with open(OUT / "results.json", "w", encoding="utf-8") as f:
        json.dump(jsonable(report), f, ensure_ascii=False, indent=1, default=str)
    finalize()


if __name__ == "__main__":
    main()
