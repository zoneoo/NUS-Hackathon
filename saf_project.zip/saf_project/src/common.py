"""Shared helpers: paths, parameters, distances, land check."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
EXT = ROOT / "data" / "ext"
CLEAN = ROOT / "data" / "clean"
OUT = ROOT / "outputs"
CONFIG = ROOT / "config" / "params.yaml"

EARTH_R_KM = 6371.0088


def load_params() -> dict:
    with open(CONFIG, encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_farms() -> pd.DataFrame:
    return pd.read_csv(CLEAN / "farms_clean.csv")


def load_airports() -> pd.DataFrame:
    return pd.read_csv(CLEAN / "airports4.csv")


def haversine_km(lat1, lon1, lat2, lon2):
    """Great-circle distance in km; broadcasts over numpy arrays."""
    lat1, lon1, lat2, lon2 = map(np.radians, (lat1, lon1, lat2, lon2))
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2) ** 2
    return 2 * EARTH_R_KM * np.arcsin(np.sqrt(np.clip(a, 0, 1)))


def dist_matrix(lat_a, lon_a, lat_b, lon_b, road_factor: float) -> np.ndarray:
    """Official rule: road distance = great-circle distance x road factor (1.3)."""
    lat_a = np.asarray(lat_a)[:, None]
    lon_a = np.asarray(lon_a)[:, None]
    lat_b = np.asarray(lat_b)[None, :]
    lon_b = np.asarray(lon_b)[None, :]
    return haversine_km(lat_a, lon_a, lat_b, lon_b) * road_factor


# ---- local planar projection (equirectangular, km) used by the Weber refinement ----
LAT0 = -1.0  # Kalimantan centre latitude; cos(-1 deg) = 0.99985, distortion negligible


def to_xy(lat, lon):
    k = np.pi / 180 * EARTH_R_KM
    return np.asarray(lon) * k * np.cos(np.radians(LAT0)), np.asarray(lat) * k


def to_latlon(x, y):
    k = np.pi / 180 * EARTH_R_KM
    return np.asarray(y) / k, np.asarray(x) / (k * np.cos(np.radians(LAT0)))


# ---- Kalimantan land check ----
_LAND = None


def land_geom():
    global _LAND
    if _LAND is None:
        from shapely.geometry import shape

        with open(EXT / "kalimantan_land.geojson", encoding="utf-8") as f:
            gj = json.load(f)
        _LAND = shape(gj["features"][0]["geometry"])
    return _LAND


def on_land(lat: float, lon: float) -> bool:
    from shapely.geometry import Point

    return land_geom().contains(Point(lon, lat))


def project_to_land(lat: float, lon: float, inset_km: float = 2.0):
    """Return (lat, lon, moved_km). Points outside Kalimantan move to the nearest land
    point, nudged `inset_km` inland so they stay valid after rounding."""
    from shapely.geometry import Point
    from shapely.ops import nearest_points

    geom = land_geom()
    p = Point(lon, lat)
    if geom.contains(p):
        return lat, lon, 0.0
    q = nearest_points(geom, p)[0]
    inner = geom.buffer(-inset_km / 111.0)
    if not inner.is_empty:
        q = nearest_points(inner, q)[0]
    moved = float(haversine_km(lat, lon, q.y, q.x))
    return q.y, q.x, moved
