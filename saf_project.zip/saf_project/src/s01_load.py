"""Stage 1: read the official files, validate them, and write params.yaml.

Every number in params.yaml comes from challenge3_parameters.xlsx / challenge3_airports_4.csv,
except the entries under `own_assumptions`, which are our stated choices.
"""
import pandas as pd
import yaml

from common import CLEAN, CONFIG, RAW, on_land


def main():
    CLEAN.mkdir(parents=True, exist_ok=True)
    CONFIG.parent.mkdir(parents=True, exist_ok=True)

    farms = pd.read_csv(RAW / "kalimantan_80_locations_6800kt_full_range.csv")
    airports = pd.read_csv(RAW / "challenge3_airports_4.csv")
    xls = RAW / "challenge3_parameters.xlsx"
    fac = pd.read_excel(xls, sheet_name="facilities", header=2)
    trn = pd.read_excel(xls, sheet_name="transport", header=2)
    asm = pd.read_excel(xls, sheet_name="assumptions", header=0)

    # ---------- validation ----------
    assert len(farms) == 80 and farms.location_id.is_unique
    assert farms.isna().sum().sum() == 0
    assert abs(farms.production_kilotons.sum() - 6800) < 1e-6
    assert (farms.production_tonnes == (farms.production_kilotons * 1000).round()).all()
    assert len(airports) == 4 and set(airports.iata) == {"PNK", "PKN", "BPN", "TRK"}
    assert airports.saf_demand_kt_per_year.sum() == 1200
    for df in (farms, airports):
        assert df.latitude.between(-4.5, 4.5).all() and df.longitude.between(108, 119.5).all()
    farms_off_land = [r.location_id for r in farms.itertuples() if not on_land(r.latitude, r.longitude)]
    for r in fac.itertuples():
        assert abs(r.annualised_capex_usd_per_year - r.capex_usd / 20) < 1
        assert abs(r.fixed_opex_usd_per_year - 0.05 * r.capex_usd) < 1

    farms.to_csv(CLEAN / "farms_clean.csv", index=False)
    airports.to_csv(CLEAN / "airports4.csv", index=False)

    def fac_row(f, s):
        r = fac[(fac.facility == f) & (fac["size"] == s)].iloc[0]
        return {"capex": float(r.capex_usd),
                "capacity_t": float(r.capacity_kt_biomass_in_per_year) * 1000,
                "fixed_annual": float(r.annualised_capex_usd_per_year + r.fixed_opex_usd_per_year),
                "var_per_t": float(r.variable_opex_usd_per_tonne_in)}

    rate = dict(zip(trn.leg, trn.cost_usd_per_tonne_km))
    params = {
        "source": "challenge3_parameters.xlsx + challenge3_airports_4.csv (official update)",
        "depot": {"Small": fac_row("Depot", "Small"), "Large": fac_row("Depot", "Large")},
        "refinery": {"Small": fac_row("Refinery", "Small"), "Large": fac_row("Refinery", "Large")},
        "rates": {"farm_depot": float(rate["Farm to depot"]),
                  "depot_refinery": float(rate["Depot to refinery"]),
                  "refinery_airport": float(rate["Refinery to airport"])},
        "trucks_t": {r.leg: {"small": int(r.small_truck_t), "large": int(r.large_truck_t)}
                     for r in trn.itertuples()},
        "yield": 0.20,
        "depot_mass_ratio": 1.0,
        "road_factor": 1.3,
        "demand_t": {r.iata: float(r.saf_demand_kt_per_year) * 1000 for r in airports.itertuples()},
        "barge_airports": ["TRK"],
        "own_assumptions": {
            "barge_distance": "great-circle x 1.3, same as road (official text only fixes the rate)",
            "split_shipments": "a farm may split its biomass across depots (continuous flows)",
            "partial_sites": "a site may be partly used; only 6,000 kt is needed",
            "co_location": "depots may share a site with a refinery (rule: anywhere on land)",
            "max_depots_at_refinery_site": 12,
            "max_depots_elsewhere": 1,
            "max_refineries_per_site": 3,
            "land_data": "Natural Earth 1:10m Admin-1, 5 Kalimantan provinces, fetched by s00 script",
        },
    }
    with open(CONFIG, "w", encoding="utf-8") as f:
        yaml.safe_dump(params, f, sort_keys=False, allow_unicode=True)

    print("farms:", len(farms), "total kt:", farms.production_kilotons.sum())
    print("demand kt:", airports.saf_demand_kt_per_year.sum(),
          "-> biomass needed kt:", airports.saf_demand_kt_per_year.sum() / params["yield"])
    print("farms not inside the Natural Earth Kalimantan polygon:", farms_off_land)
    print("assumption sheet:")
    for r in asm.itertuples():
        print("  -", r.parameter, ":", r.value)
    print("params.yaml written")


if __name__ == "__main__":
    main()
