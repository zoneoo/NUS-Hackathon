"""Stage 4: the MILP (three-echelon network flow + facility opening).

Units inside the solver: flows and capacities in kt/year, money in USD million/year.
Solved with HiGHS through scipy.optimize.milp.

Variables (all >= 0)
  x[i,j]  farm i -> depot j (kt biomass)        u[j,k]  depot j -> refinery k (kt biomass)
  v[k,a]  refinery k -> airport a (kt SAF)      q[j,s], r[k,s]  throughput by size (for variable OpEx)
  z[j,s]  number of depots of size s at j (int) w[k,s]  number of refineries of size s at k (int)
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy.optimize import Bounds, LinearConstraint, milp

from common import haversine_km

SIZES = ("Small", "Large")


@dataclass
class Scenario:
    yield_: float = 0.20
    demand_kt: float = 300.0          # per airport, kt SAF / year
    road_factor: float = 1.3
    c1: float = 0.10                  # farm -> depot, USD/t/km
    c2: float = 0.12                  # depot -> refinery
    c3: float = 0.08                  # refinery -> airport (barge to TRK at the same rate)
    ref_capex_mult: float = 1.0       # scales refinery CapEx (and so its fixed OpEx)
    max_farm_depot_km: float | None = None   # "distributed depots" scenario (road km)
    force_n_refineries: int | None = None
    single_source: bool = False
    label: str = "base"
    extra: dict = field(default_factory=dict)


def gc_matrix(lat_a, lon_a, lat_b, lon_b):
    return haversine_km(np.asarray(lat_a)[:, None], np.asarray(lon_a)[:, None],
                        np.asarray(lat_b)[None, :], np.asarray(lon_b)[None, :])


def solve(farms: pd.DataFrame, airports: pd.DataFrame, depots: pd.DataFrame, refs: pd.DataFrame,
          params: dict, sc: Scenario, time_limit: float = 120, gap: float = 0.005, verbose=False,
          warm_start=None):
    t0 = time.time()
    nI, nJ, nK, nA = len(farms), len(depots), len(refs), len(airports)
    s = farms.production_kilotons.to_numpy(float)
    D = np.full(nA, sc.demand_kt)
    QD = np.array([params["depot"][z]["capacity_t"] / 1000 for z in SIZES])
    QR = np.array([params["refinery"][z]["capacity_t"] / 1000 for z in SIZES])
    FD = np.array([params["depot"][z]["fixed_annual"] / 1e6 for z in SIZES])
    FR = np.array([params["refinery"][z]["fixed_annual"] / 1e6 for z in SIZES]) * sc.ref_capex_mult
    oD = np.array([params["depot"][z]["var_per_t"] / 1000 for z in SIZES])
    oR = np.array([params["refinery"][z]["var_per_t"] / 1000 for z in SIZES])
    own = params["own_assumptions"]
    MD = np.where(depots.is_ref_site.to_numpy(bool), own["max_depots_at_refinery_site"],
                  own["max_depots_elsewhere"]).astype(float)
    MK = float(own["max_refineries_per_site"])

    g_fd = gc_matrix(farms.latitude, farms.longitude, depots.lat, depots.lon)
    g_dr = gc_matrix(depots.lat, depots.lon, refs.lat, refs.lon)
    g_ra = gc_matrix(refs.lat, refs.lon, airports.latitude, airports.longitude)
    tau = sc.road_factor

    # ---- variable layout ----
    sizes = {"x": nI * nJ, "u": nJ * nK, "v": nK * nA, "q": nJ * 2, "r": nK * 2, "z": nJ * 2, "w": nK * 2}
    if sc.single_source:
        sizes["a"] = nI * nJ
    off, n = {}, 0
    for key, m in sizes.items():
        off[key] = n
        n += m

    def ix(key, *idx):
        if key in ("x", "a"):
            i, j = idx; return off[key] + i * nJ + j
        if key == "u":
            j, k = idx; return off[key] + j * nK + k
        if key == "v":
            k, a = idx; return off[key] + k * nA + a
        if key in ("q", "z"):
            j, z = idx; return off[key] + j * 2 + z
        if key in ("r", "w"):
            k, z = idx; return off[key] + k * 2 + z

    c = np.zeros(n)
    c[off["x"]:off["x"] + nI * nJ] = (tau * sc.c1 * g_fd / 1000).ravel()
    c[off["u"]:off["u"] + nJ * nK] = (tau * sc.c2 * g_dr / 1000).ravel()
    c[off["v"]:off["v"] + nK * nA] = (tau * sc.c3 * g_ra / 1000).ravel()
    c[off["q"]:off["q"] + nJ * 2] = np.tile(oD, nJ)
    c[off["r"]:off["r"] + nK * 2] = np.tile(oR, nK)
    c[off["z"]:off["z"] + nJ * 2] = np.tile(FD, nJ)
    c[off["w"]:off["w"] + nK * 2] = np.tile(FR, nK)

    lb = np.zeros(n)
    ub = np.full(n, np.inf)
    integrality = np.zeros(n)
    integrality[off["z"]:off["z"] + nJ * 2] = 1
    integrality[off["w"]:off["w"] + nK * 2] = 1
    ub[off["z"]:off["z"] + nJ * 2] = np.repeat(MD, 2)
    ub[off["w"]:off["w"] + nK * 2] = MK
    limit = sc.max_farm_depot_km if sc.max_farm_depot_km is not None else sc.extra.get("x_filter_km", 600)
    too_far = (g_fd * tau > limit).ravel()
    ub[off["x"]:off["x"] + nI * nJ][too_far] = 0.0
    if sc.extra.get("fix_w") is not None:   # keep refinery sites fixed, re-optimise the depot layer only
        ub[off["w"]:off["w"] + nK * 2] = 0.0
        for k, nS_, nL_ in sc.extra["fix_w"]:
            lb[ix("w", k, 0)] = ub[ix("w", k, 0)] = nS_
            lb[ix("w", k, 1)] = ub[ix("w", k, 1)] = nL_
    if sc.single_source:
        integrality[off["a"]:off["a"] + nI * nJ] = 1
        ub[off["a"]:off["a"] + nI * nJ] = 1

    rows, cols, vals, lo, hi = [], [], [], [], []
    r = 0

    def row(entries, lower, upper):
        nonlocal r
        for col, val in entries:
            rows.append(r); cols.append(col); vals.append(val)
        lo.append(lower); hi.append(upper)
        r += 1

    for i in range(nI):                                   # (1) supply
        row([(ix("x", i, j), 1.0) for j in range(nJ)], -np.inf, s[i])
    for j in range(nJ):                                   # (2) depot balance, no mass loss
        row([(ix("x", i, j), 1.0) for i in range(nI)] + [(ix("u", j, k), -1.0) for k in range(nK)], 0, 0)
    for j in range(nJ):                                   # (3) throughput split by size
        row([(ix("q", j, z), 1.0) for z in range(2)] + [(ix("x", i, j), -1.0) for i in range(nI)], 0, 0)
        for z in range(2):                                # (3b) depot capacity
            row([(ix("q", j, z), 1.0), (ix("z", j, z), -QD[z])], -np.inf, 0)
        row([(ix("z", j, z), 1.0) for z in range(2)], -np.inf, MD[j])   # (4) count limit
    for k in range(nK):                                   # (5) refinery yield
        row([(ix("u", j, k), sc.yield_) for j in range(nJ)] + [(ix("v", k, a), -1.0) for a in range(nA)], 0, 0)
        row([(ix("r", k, z), 1.0) for z in range(2)] + [(ix("u", j, k), -1.0) for j in range(nJ)], 0, 0)  # (6)
        for z in range(2):                                # (6b) refinery capacity (biomass intake)
            row([(ix("r", k, z), 1.0), (ix("w", k, z), -QR[z])], -np.inf, 0)
        row([(ix("w", k, z), 1.0) for z in range(2)], -np.inf, MK)       # (7) unit limit
    for a in range(nA):                                   # (8) demand
        row([(ix("v", k, a), 1.0) for k in range(nK)], D[a], np.inf)
    # (9) strengthening on single-depot candidate sites: no flow into an unopened depot
    for j in np.where(MD == 1)[0]:
        for i in range(nI):
            if ub[ix("x", i, j)] > 0:
                row([(ix("x", i, j), 1.0), (ix("z", j, 0), -s[i]), (ix("z", j, 1), -s[i])], -np.inf, 0)
    # (10) co-located depot clusters only where a refinery is open, with strong flow links
    B = nA * sc.demand_kt / sc.yield_
    ref_idx = depots["ref_idx"].to_numpy(int) if "ref_idx" in depots else np.full(nJ, -1)
    for j in np.where(ref_idx >= 0)[0]:
        k = ref_idx[j]
        for z in range(2):
            row([(ix("z", j, z), 1.0), (ix("w", k, 0), -MD[j]), (ix("w", k, 1), -MD[j])], -np.inf, 0)
        for i in range(nI):
            if ub[ix("x", i, j)] > 0:
                row([(ix("x", i, j), 1.0), (ix("w", k, 0), -s[i]), (ix("w", k, 1), -s[i])], -np.inf, 0)
    # (11) aggregate capacity (implied, but lets the solver derive knapsack cover cuts)
    row([(ix("w", k, z), QR[z]) for k in range(nK) for z in range(2)], B, np.inf)
    row([(ix("z", j, z), QD[z]) for j in range(nJ) for z in range(2)], B, np.inf)
    if sc.force_n_refineries is not None:
        row([(ix("w", k, z), 1.0) for k in range(nK) for z in range(2)],
            sc.force_n_refineries, sc.force_n_refineries)
    if sc.single_source:
        for i in range(nI):
            row([(ix("a", i, j), 1.0) for j in range(nJ)], 1, 1)
            for j in range(nJ):
                row([(ix("x", i, j), 1.0), (ix("a", i, j), -s[i])], -np.inf, 0)

    A = sp.csc_matrix((vals, (rows, cols)), shape=(r, n))
    X, info = run_highs(c, A, np.array(lo), np.array(hi), lb, ub, integrality, time_limit, gap,
                        verbose, warm_start)
    runtime = time.time() - t0
    if X is None:
        return {"status": info["status"], "message": info["status"], "feasible": False, "runtime": runtime,
                "scenario": dict(sc.__dict__)}
    res_fun, res_gap, res_bound, res_status = info["obj"], info["gap"], info["bound"], info["status"]
    x = X[off["x"]:off["x"] + nI * nJ].reshape(nI, nJ)
    u = X[off["u"]:off["u"] + nJ * nK].reshape(nJ, nK)
    v = X[off["v"]:off["v"] + nK * nA].reshape(nK, nA)
    q = X[off["q"]:off["q"] + nJ * 2].reshape(nJ, 2)
    rr = X[off["r"]:off["r"] + nK * 2].reshape(nK, 2)
    zc = np.round(X[off["z"]:off["z"] + nJ * 2].reshape(nJ, 2)).astype(int)
    wc = np.round(X[off["w"]:off["w"] + nK * 2].reshape(nK, 2)).astype(int)
    for arr in (x, u, v, q, rr):
        arr[arr < 1e-7] = 0.0

    sol = {
        "feasible": True, "status": res_status, "message": res_status, "runtime": runtime,
        "objective_musd": res_fun, "mip_gap": res_gap, "dual_bound": res_bound, "layout": (off, nI, nJ, nK, nA), "x_full": X,
        "scenario": {k: v_ for k, v_ in sc.__dict__.items()},
        "x": x, "u": u, "v": v, "q": q, "r": rr, "z": zc, "w": wc,
        "g_fd": g_fd, "g_dr": g_dr, "g_ra": g_ra,
    }
    sol.update(cost_breakdown(sol, params, sc))
    return sol


def run_highs(c, A, lo, hi, lb, ub, integrality, time_limit, gap, verbose, warm_start):
    import highspy
    inf = highspy.kHighsInf
    h = highspy.Highs()
    h.setOptionValue("output_flag", bool(verbose))
    h.setOptionValue("time_limit", float(time_limit))
    h.setOptionValue("mip_rel_gap", float(gap))
    lp = highspy.HighsLp()
    n, m = len(c), A.shape[0]
    lp.num_col_, lp.num_row_ = n, m
    lp.col_cost_ = c
    lp.col_lower_ = lb
    lp.col_upper_ = np.where(np.isinf(ub), inf, ub)
    lp.row_lower_ = np.where(np.isinf(lo), -inf, lo)
    lp.row_upper_ = np.where(np.isinf(hi), inf, hi)
    lp.a_matrix_.format_ = highspy.MatrixFormat.kColwise
    lp.a_matrix_.start_ = A.indptr
    lp.a_matrix_.index_ = A.indices
    lp.a_matrix_.value_ = A.data
    lp.a_matrix_.num_col_, lp.a_matrix_.num_row_ = n, m
    lp.integrality_ = [highspy.HighsVarType.kInteger if t else highspy.HighsVarType.kContinuous
                       for t in integrality]
    h.passModel(lp)
    if warm_start is not None and len(warm_start) == n:
        ws = highspy.HighsSolution()
        ws.col_value = list(np.asarray(warm_start, float))
        ws.value_valid = True
        h.setSolution(ws)
    h.run()
    status = h.modelStatusToString(h.getModelStatus())
    info = h.getInfo()
    if info.primal_solution_status == 0 or "nfeasible" in status:
        return None, {"status": status}
    X = np.array(h.getSolution().col_value)
    return X, {"status": status, "obj": float(info.objective_function_value),
               "gap": float(info.mip_gap), "bound": float(info.mip_dual_bound)}


def cost_breakdown(sol, params, sc: Scenario):
    """Independent recomputation of every cost line from the solution (USD million/year)."""
    tau = sc.road_factor
    FD = np.array([params["depot"][z]["fixed_annual"] for z in SIZES]) / 1e6
    FR = np.array([params["refinery"][z]["fixed_annual"] for z in SIZES]) / 1e6 * sc.ref_capex_mult
    oD = np.array([params["depot"][z]["var_per_t"] for z in SIZES]) / 1000
    oR = np.array([params["refinery"][z]["var_per_t"] for z in SIZES]) / 1000
    T1 = float(np.sum(sol["x"] * sol["g_fd"])) * 1000   # t*km (great-circle)
    T2 = float(np.sum(sol["u"] * sol["g_dr"])) * 1000
    T3 = float(np.sum(sol["v"] * sol["g_ra"])) * 1000
    out = {
        "refinery_fixed": float(np.sum(sol["w"] * FR)),
        "depot_fixed": float(np.sum(sol["z"] * FD)),
        "refinery_var": float(np.sum(sol["r"] * oR)),
        "depot_var": float(np.sum(sol["q"] * oD)),
        "transport_fd": tau * sc.c1 * T1 / 1e6,
        "transport_dr": tau * sc.c2 * T2 / 1e6,
        "transport_ra": tau * sc.c3 * T3 / 1e6,
        "tkm_gc": {"fd": T1, "dr": T2, "ra": T3},
    }
    out["transport"] = out["transport_fd"] + out["transport_dr"] + out["transport_ra"]
    out["total_musd"] = (out["refinery_fixed"] + out["depot_fixed"] + out["refinery_var"]
                         + out["depot_var"] + out["transport"])
    out["biomass_used_kt"] = float(sol["x"].sum())
    out["saf_kt"] = float(sol["v"].sum())
    out["n_ref"] = {z: int(sol["w"][:, i].sum()) for i, z in enumerate(SIZES)}
    out["n_depot"] = {z: int(sol["z"][:, i].sum()) for i, z in enumerate(SIZES)}
    return out


# ---------------------------------------------------------------------------------------------
# Plans: one format for MILP solutions and the greedy baseline, evaluated by the same function.
# ---------------------------------------------------------------------------------------------
def to_plan(sol, farms, airports, depots, refs, params):
    QR_L = params["refinery"]["Large"]["capacity_t"] / 1000
    QD_L = params["depot"]["Large"]["capacity_t"] / 1000
    plan = {"refineries": [], "depots": [], "flows_fd": [], "flows_dr": [], "flows_ra": []}
    x, u, v, z, w = sol["x"], sol["u"], sol["v"], sol["z"], sol["w"]
    ref_ids = {}
    for k in np.where(w.sum(1) > 0)[0]:
        rid = f"R{len(ref_ids) + 1}"
        ref_ids[k] = rid
        plan["refineries"].append({"id": rid, "source": refs.source[k], "lat": float(refs.lat[k]),
                                   "lon": float(refs.lon[k]), "n_L": int(w[k, 1]), "n_S": int(w[k, 0]),
                                   "intake_kt": float(u[:, k].sum())})
    dep_ids = {}
    for j in np.where(z.sum(1) > 0)[0]:
        if x[:, j].sum() < 1e-6:
            continue
        did = f"D{len(dep_ids) + 1}"
        dep_ids[j] = did
        rk = int(depots.ref_idx[j]) if "ref_idx" in depots and depots.ref_idx[j] >= 0 else None
        plan["depots"].append({"id": did, "source": depots.source[j], "lat": float(depots.lat[j]),
                               "lon": float(depots.lon[j]), "n_L": int(z[j, 1]), "n_S": int(z[j, 0]),
                               "throughput_kt": float(x[:, j].sum()),
                               "colocated_with": ref_ids.get(rk) if rk is not None else None})
    for i, j in zip(*np.nonzero(x)):
        plan["flows_fd"].append({"farm": farms.location_id[i], "depot": dep_ids[j], "kt": float(x[i, j]),
                                 "gc_km": float(sol["g_fd"][i, j])})
    for j, k in zip(*np.nonzero(u)):
        plan["flows_dr"].append({"depot": dep_ids[j], "refinery": ref_ids[k], "kt": float(u[j, k]),
                                 "gc_km": float(sol["g_dr"][j, k])})
    for k, a in zip(*np.nonzero(v)):
        plan["flows_ra"].append({"refinery": ref_ids[k], "airport": airports.iata[a], "kt": float(v[k, a]),
                                 "gc_km": float(sol["g_ra"][k, a])})
    return plan


def evaluate_plan(plan, params, sc: Scenario):
    """Cost lines (USD million/year) of a plan; Large units are filled first (lower variable OpEx)."""
    P = params
    tau = sc.road_factor
    out = {"refinery_fixed": 0.0, "depot_fixed": 0.0, "refinery_var": 0.0, "depot_var": 0.0}
    for r in plan["refineries"]:
        out["refinery_fixed"] += sc.ref_capex_mult * (r["n_L"] * P["refinery"]["Large"]["fixed_annual"]
                                                      + r["n_S"] * P["refinery"]["Small"]["fixed_annual"]) / 1e6
        big = min(r["intake_kt"], r["n_L"] * P["refinery"]["Large"]["capacity_t"] / 1000)
        out["refinery_var"] += (big * P["refinery"]["Large"]["var_per_t"]
                                + (r["intake_kt"] - big) * P["refinery"]["Small"]["var_per_t"]) / 1000
    for d in plan["depots"]:
        out["depot_fixed"] += (d["n_L"] * P["depot"]["Large"]["fixed_annual"]
                               + d["n_S"] * P["depot"]["Small"]["fixed_annual"]) / 1e6
        big = min(d["throughput_kt"], d["n_L"] * P["depot"]["Large"]["capacity_t"] / 1000)
        out["depot_var"] += (big * P["depot"]["Large"]["var_per_t"]
                             + (d["throughput_kt"] - big) * P["depot"]["Small"]["var_per_t"]) / 1000
    T1 = sum(f["kt"] * f["gc_km"] for f in plan["flows_fd"]) * 1000
    T2 = sum(f["kt"] * f["gc_km"] for f in plan["flows_dr"]) * 1000
    T3 = sum(f["kt"] * f["gc_km"] for f in plan["flows_ra"]) * 1000
    out["transport_fd"] = tau * sc.c1 * T1 / 1e6
    out["transport_dr"] = tau * sc.c2 * T2 / 1e6
    out["transport_ra"] = tau * sc.c3 * T3 / 1e6
    out["transport"] = out["transport_fd"] + out["transport_dr"] + out["transport_ra"]
    out["total_musd"] = sum(out[k] for k in ("refinery_fixed", "depot_fixed", "refinery_var", "depot_var",
                                             "transport"))
    out["tkm_gc"] = {"fd": T1, "dr": T2, "ra": T3}
    out["fixed_at_m1"] = {"refinery": out["refinery_fixed"] / sc.ref_capex_mult, "depot": out["depot_fixed"]}
    out["var_opex"] = out["refinery_var"] + out["depot_var"]
    out["biomass_used_kt"] = sum(f["kt"] for f in plan["flows_fd"])
    out["saf_kt"] = sum(f["kt"] for f in plan["flows_ra"])
    out["n_ref"] = {"Large": sum(r["n_L"] for r in plan["refineries"]),
                    "Small": sum(r["n_S"] for r in plan["refineries"])}
    out["n_depot"] = {"Large": sum(d["n_L"] for d in plan["depots"]),
                      "Small": sum(d["n_S"] for d in plan["depots"])}
    out["colocated_share"] = (sum(d["throughput_kt"] for d in plan["depots"] if d.get("colocated_with"))
                              / max(out["biomass_used_kt"], 1e-9))
    return out
