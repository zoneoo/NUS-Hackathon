"""Stage 3: candidate sites for depots (J) and refineries (K).

K (refinery candidates): 8 district weighted centroids + 8 district Weber points
   + west/east macro-cluster Weber points + 4 airports.
J (depot candidates): 80 farm sites + per-district weighted k-means centroids (two K values)
   + every refinery candidate (so a depot can share a site with a refinery).
Every candidate is moved onto Kalimantan land (Natural Earth polygon, 2 km inland) if needed.
"""
from math import ceil

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans

from common import CLEAN, haversine_km, load_airports, load_farms, project_to_land, to_latlon, to_xy


def weber_point(lat, lon, w, iters=500, tol=1e-6):
    """Weighted geometric median (Weiszfeld) in local planar km coordinates."""
    x, y = to_xy(lat, lon)
    w = np.asarray(w, float)
    px, py = np.average(x, weights=w), np.average(y, weights=w)
    for _ in range(iters):
        d = np.hypot(x - px, y - py)
        d = np.maximum(d, 1e-9)
        nx, ny = np.sum(w * x / d) / np.sum(w / d), np.sum(w * y / d) / np.sum(w / d)
        if np.hypot(nx - px, ny - py) < tol:
            px, py = nx, ny
            break
        px, py = nx, ny
    la, lo = to_latlon(px, py)
    return float(la), float(lo)


def add(rows, kind, source, lat, lon):
    la, lo, moved = project_to_land(lat, lon)
    rows.append({"kind": kind, "source": source, "lat": la, "lon": lo,
                 "raw_lat": lat, "raw_lon": lon, "moved_to_land_km": round(moved, 2)})


def dedupe(df, tol_km=0.5):
    keep = []
    for r in df.itertuples():
        if all(haversine_km(r.lat, r.lon, k.lat, k.lon) > tol_km for k in keep):
            keep.append(r)
    return pd.DataFrame(keep).drop(columns="Index", errors="ignore").reset_index(drop=True)


def build_refinery_candidates(farms, airports):
    rows = []
    for d, g in farms.groupby("district"):
        w = g.production_kilotons
        add(rows, "refinery", f"centroid:{d}", np.average(g.latitude, weights=w),
            np.average(g.longitude, weights=w))
        add(rows, "refinery", f"weber:{d}", *weber_point(g.latitude, g.longitude, w))
    west = farms.longitude < 113.5
    for name, g in (("west", farms[west]), ("east", farms[~west])):
        add(rows, "refinery", f"weber:{name}-macro", *weber_point(g.latitude, g.longitude, g.production_kilotons))
    for a in airports.itertuples():
        add(rows, "refinery", f"airport:{a.iata}", a.latitude, a.longitude)
    df = pd.DataFrame(rows)
    # centroid and Weber point of a district are often a few km apart; near-duplicates only add
    # symmetry to the MILP, so keep one site per 15 km (Weber points first: they minimise linear cost)
    df["prio"] = df.source.str.split(":").str[0].map({"weber": 0, "airport": 1, "centroid": 2})
    df = df.sort_values("prio", kind="stable").drop(columns="prio")
    return dedupe(df, tol_km=15.0)


def build_depot_candidates(farms, refs):
    rows = []
    for f in farms.itertuples():
        add(rows, "depot", f"farm:{f.location_id}", f.latitude, f.longitude)
    for d, g in farms.groupby("district"):
        total = g.production_kilotons.sum()
        x, y = to_xy(g.latitude.values, g.longitude.values)
        X = np.column_stack([x, y])
        for k in sorted({ceil(total / 300), ceil(total / 150)}):
            k = min(k, len(g))
            km = KMeans(n_clusters=k, n_init=10, random_state=0).fit(X, sample_weight=g.production_kilotons)
            for c, (cx, cy) in enumerate(km.cluster_centers_):
                la, lo = to_latlon(cx, cy)
                add(rows, "depot", f"kmeans:{d}:K{k}:{c}", float(la), float(lo))
    for k, r in enumerate(refs.itertuples()):
        rows.append({"kind": "depot", "source": f"co-located:{r.source}", "lat": r.lat, "lon": r.lon,
                     "raw_lat": r.raw_lat, "raw_lon": r.raw_lon, "moved_to_land_km": r.moved_to_land_km,
                     "ref_idx": k})
    df = pd.DataFrame(rows)
    df["ref_idx"] = df["ref_idx"].fillna(-1).astype(int)
    # co-located copies first so dedupe keeps them (they carry the higher depot-count limit)
    df["is_ref_site"] = df.source.str.startswith("co-located")
    df = df.sort_values("is_ref_site", ascending=False, kind="stable")
    return dedupe(df, tol_km=0.5)


def main():
    farms, airports = load_farms(), load_airports()
    refs = build_refinery_candidates(farms, airports)
    depots = build_depot_candidates(farms, refs)
    refs.to_csv(CLEAN / "refinery_candidates.csv", index=False)
    depots.to_csv(CLEAN / "depot_candidates.csv", index=False)
    print(f"refinery candidates K = {len(refs)}  (moved to land: {(refs.moved_to_land_km > 0).sum()})")
    print(refs[["source", "lat", "lon", "moved_to_land_km"]].round(3).to_string())
    print(f"\ndepot candidates J = {len(depots)}  (co-located refinery sites: {depots.is_ref_site.sum()}, "
          f"moved to land: {(depots.moved_to_land_km > 0).sum()})")
    print(depots.source.str.split(":").str[0].value_counts().to_string())


if __name__ == "__main__":
    main()
