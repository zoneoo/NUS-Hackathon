"""Stage 6: sensitivity analysis -> a "plan library" for the interactive slide.

Variables (why): see README / slide 6.
  demand per airport D (kt SAF): 300-340, step 10      -> changes biomass needed and refinery count
  yield y (t SAF / t biomass):   0.18-0.25, step 0.01  -> same; y < 0.1765 makes 1,200 kt infeasible
  refinery CapEx multiplier m:   0.8-1.2 (continuous)  -> largest cost line
  road factor tau:               1.2-1.5 (continuous)  -> scales every transport cost
  depot->refinery rate c2:       0.08-0.12 (continuous)-> flips depots between "at refinery" and "near farms"

For every feasible (D, y) grid point we re-optimise the MILP a few times and store each optimal plan
as six numbers: refinery fixed cost (at m = 1), depot fixed cost, variable OpEx and great-circle
tonne-km on the three legs. For any slider position the browser evaluates every stored plan for that
(D, y) EXACTLY (cost is linear in m, tau and c2 once the plan is fixed) and shows the cheapest one.
"""
import json
import sys
import time

import numpy as np
import pandas as pd

from common import CLEAN, OUT, load_airports, load_farms, load_params
from s04_model import Scenario, evaluate_plan, solve, to_plan

D_GRID = [300, 310, 320, 330, 340]
Y_GRID = [0.18, 0.19, 0.20, 0.21, 0.22, 0.23, 0.24, 0.25]
SUPPLY = 6800.0


def plan_record(plan, cost, D, y, kind, sc, gap, runtime, w=None):
    return {
        "w": [[int(k), int(w[k, 0]), int(w[k, 1])] for k in range(len(w)) if w[k].sum() > 0] if w is not None else None,
        "D": D, "y": y, "kind": kind,
        "solved_at": {"tau": sc.road_factor, "m": sc.ref_capex_mult, "c2": sc.c2},
        "RF": cost["fixed_at_m1"]["refinery"], "DF": cost["depot_fixed"], "VO": cost["var_opex"],
        "T1": cost["tkm_gc"]["fd"] / 1e6, "T2": cost["tkm_gc"]["dr"] / 1e6, "T3": cost["tkm_gc"]["ra"] / 1e6,
        "nL": cost["n_ref"]["Large"], "nS": cost["n_ref"]["Small"],
        "nDepot": cost["n_depot"]["Large"] + cost["n_depot"]["Small"],
        "colocated": round(cost["colocated_share"], 3), "biomass": round(cost["biomass_used_kt"], 1),
        "refs": [{"lat": round(r["lat"], 3), "lon": round(r["lon"], 3), "nL": r["n_L"], "nS": r["n_S"],
                  "kt": round(r["intake_kt"], 1)} for r in plan["refineries"]],
        "depots_far": sum(1 for d in plan["depots"] if not d.get("colocated_with")),
        "gap": gap, "runtime": round(runtime, 1),
    }


def wait_for_hub(out_path, D, y, timeout=3600):
    t0 = time.time()
    while time.time() - t0 < timeout:
        if out_path.exists():
            for line in out_path.read_text().splitlines():
                r = json.loads(line)
                if r["D"] == D and abs(r["y"] - y) < 1e-9 and r["kind"] == "hub_base":
                    return "infeasible" if r.get("infeasible") else r["w"]
        time.sleep(10)
    raise TimeoutError(f"no hub_base plan for D={D} y={y}")


def main(stage="all"):
    params, farms, airports = load_params(), load_farms(), load_airports()
    depots = pd.read_csv(CLEAN / "depot_candidates_final.csv")
    refs = pd.read_csv(CLEAN / "refinery_candidates_final.csv")
    hubs = depots[depots.is_ref_site].reset_index(drop=True)
    out_path = OUT / "sensitivity_plans.jsonl"
    done = set()
    if out_path.exists():
        for line in out_path.read_text().splitlines():
            r = json.loads(line)
            done.add((r["D"], r["y"], r["kind"]))
    runs = []
    for D in D_GRID:
        for y in Y_GRID:
            if 4 * D / y > SUPPLY + 1e-6:
                continue
            runs.append((D, y, "hub_base", Scenario(demand_kt=D, yield_=y), hubs, 0.002, 120))
            if abs(y - 0.20) < 1e-9:  # spot-check: does a dispersal-friendly setting change the plan?
                runs.append((D, y, "hub_disperse",
                             Scenario(demand_kt=D, yield_=y, road_factor=1.5, ref_capex_mult=0.8), hubs, 0.002, 120))
    for D in D_GRID:
        for y in Y_GRID:
            if 4 * D / y > SUPPLY + 1e-6:
                continue
            runs.append((D, y, "general_c2low", Scenario(demand_kt=D, yield_=y, c2=0.08), depots, 0.002, 120))
    t0 = time.time()
    for D, y, kind, sc, J, gap, tl in runs:
        if (D, y, kind) in done:
            continue
        if stage == "hub" and not kind.startswith("hub"):
            continue
        if stage == "general" and not kind.startswith("general"):
            continue
        if kind == "general_c2low":
            # depots near farms pay off only when c2 < c1; keep the hub-optimal refinery sites for this
            # (D, y) and re-optimise the depot layer with stand-alone depots allowed
            w_fix = wait_for_hub(out_path, D, y)
            if w_fix == "infeasible":
                continue
            sc.extra["fix_w"] = w_fix
        s = solve(farms, airports, J, refs, params, sc, time_limit=tl, gap=gap)
        if not s["feasible"]:
            rec = {"D": D, "y": y, "kind": kind, "infeasible": True, "status": s["status"]}
        else:
            p = to_plan(s, farms, airports, J, refs, params)
            c = evaluate_plan(p, params, sc)
            rec = plan_record(p, c, D, y, kind, sc, s["mip_gap"], s["runtime"], s["w"])
        with open(out_path, "a") as f:
            f.write(json.dumps(rec) + "\n")
        if rec.get("infeasible"):
            msg = "INFEASIBLE"
        else:
            msg = f"nL={rec['nL']} nS={rec['nS']} gap={rec['gap']:.3%} {rec['runtime']}s"
        print(f"[{time.time() - t0:6.0f}s] D={D} y={y:.2f} {kind}: {msg}", flush=True)


def validate_library(n_checks=6, seed=1):
    """Exact MILP at random (tau, m, c2) vs the library's cheapest plan at the same (D, y)."""
    params, farms, airports = load_params(), load_farms(), load_airports()
    depots = pd.read_csv(CLEAN / "depot_candidates_final.csv")
    refs = pd.read_csv(CLEAN / "refinery_candidates_final.csv")
    hubs = depots[depots.is_ref_site].reset_index(drop=True)
    lib = [json.loads(l) for l in (OUT / "sensitivity_plans.jsonl").read_text().splitlines()]
    lib = [r for r in lib if not r.get("infeasible")]
    rng = np.random.default_rng(seed)
    res = []
    for _ in range(n_checks):
        D = int(rng.choice(D_GRID)); y = float(rng.choice(Y_GRID))
        while 4 * D / y > SUPPLY:
            D = int(rng.choice(D_GRID)); y = float(rng.choice(Y_GRID))
        tau, m, c2 = rng.uniform(1.2, 1.5), rng.uniform(0.8, 1.2), rng.uniform(0.10, 0.12)
        sc = Scenario(demand_kt=D, yield_=y, road_factor=tau, ref_capex_mult=m, c2=c2)
        s = solve(farms, airports, hubs, refs, params, sc, time_limit=120, gap=0.002)
        exact = s["total_musd"]
        cands = [r for r in lib if r["D"] == D and abs(r["y"] - y) < 1e-9]
        best = min(m * r["RF"] + r["DF"] + r["VO"] + tau * (0.10 * r["T1"] + c2 * r["T2"] + 0.08 * r["T3"])
                   for r in cands)
        res.append({"D": D, "y": y, "tau": tau, "m": m, "c2": c2, "exact": exact, "library": best,
                    "diff_pct": (best - exact) / exact * 100})
        print(res[-1], flush=True)
    with open(OUT / "sensitivity_validation.json", "w") as f:
        json.dump(res, f, indent=1)


if __name__ == "__main__":
    arg = sys.argv[1] if len(sys.argv) > 1 else "all"
    if arg == "validate":
        validate_library()
    else:
        main(arg)
